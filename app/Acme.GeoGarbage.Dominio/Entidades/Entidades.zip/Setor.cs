﻿using SmartDrive.Ambiental.Dominio.Entidades;
using System;
using System.Collections.Generic;

namespace SmartDrive.Ambiental.Dominio.Entidades
{
    public class Setor
    {
        public Guid IdSetor { get; set; }
        public Guid IdCliente { get; set; }
        public string NomeSetor { get; set; }
        public bool Ativo { get; set; }
        public virtual Cliente Clientes { get; set; }
        public virtual IEnumerable<SetoresDaJornada> SetoresDasJornadas { get; set; }
    }
}
