﻿using System;

namespace SmartDrive.Ambiental.Dominio.Entidades
{
    public class ConsultaDinamica
    {
        public Guid IdConsultaDinamica { get; set; }
        public string NomeConsultaDinamica { get; set; }
        public Guid IdConsultaPasta { get; set; }
        public virtual ConsultaPasta ConsultaPasta { get; set; }
    }
}