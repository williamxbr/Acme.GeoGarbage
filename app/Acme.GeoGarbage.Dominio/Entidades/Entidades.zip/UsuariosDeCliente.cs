﻿using System;

namespace SmartDrive.Ambiental.Dominio.Entidades
{
    public class UsuariosDeCliente
    {
        public Guid IdCliente { get; set; }
        public Guid IdUsuario { get; set; }
        public virtual Cliente Cliente { get; set; }
        public virtual Usuario Usuario { get; set; }
    }
}