﻿using System;
using System.Collections.Generic;

namespace SmartDrive.Ambiental.Dominio.Entidades
{
    public class ConsultaPasta
    {
        public Guid IdConsultaPasta { get; set; }
        public string NomePasta { get; set; }
        public virtual IEnumerable<ConsultaDinamica> ConsultasDinamicas { get; set; }
    }
}