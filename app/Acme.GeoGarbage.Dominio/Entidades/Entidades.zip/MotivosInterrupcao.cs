﻿using System;
using System.Collections.Generic;

namespace SmartDrive.Ambiental.Dominio.Entidades
{
    public class MotivosInterrupcao
    {
        public Guid IdMotivoInterrupcao { get; set; }
        public string Motivo { get; set; }
        public bool Ativo { get; set; }
        public virtual IEnumerable<Interrupcao> Interrupcoes { get; set; }
    }
}
